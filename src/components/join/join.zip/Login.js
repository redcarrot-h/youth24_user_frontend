import { SignArea } from 'style/StyleJoin';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser as solidUser } from '@fortawesome/free-solid-svg-icons/faUser';
import { faLock as solidLock } from '@fortawesome/free-solid-svg-icons/faLock';
import { NavLink } from 'react-router-dom';

// som
import { baseUrl } from 'apiurl';
import axios from 'axios';
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

const Login = () => {
  const [isIdFocused, setIsIdFocused] = useState(false);
  const [isPwFocused, setIsPwFocused] = useState(false);

  const handleIdFocus = () => {
    setIsIdFocused(true);
  };

  const handlePwFocus = () => {
    setIsPwFocused(true);
  };

  const handleIdBlur = () => {
    setIsIdFocused(false);
  };

  const handlePwBlur = () => {
    setIsPwFocused(false);
  };

  // som

  const navigator = useNavigate();
  const [inputs, setInputs] = useState({
    userId: '',
    userPassword: '',
  });
  const { userId, userPassword } = inputs;

  const handleValueChange = (e) => {
    setInputs({ ...inputs, [e.target.name]: e.target.value });
  };

  const config = { headers: { 'Content-Type': 'application/json' } };

  //입력한 로그인 정보 보내기
  const onSubmit = async (e) => {
    //기본 동작 막음
    e.preventDefault();
    await axios
      .post(`${baseUrl}/login`, inputs, config)
      .then((response) => {
        console.log('response: ', response.data);
        //let jwtToken = response.headers['Authorization'];
        let jwtToken = response.headers.get('Authorization');
        console.log(jwtToken);

        let jwtUserName = response.data.userName;
        let jwtUserId = response.data.userId;
        let jwtAuthRole = response.data.authRole;

        localStorage.setItem('Authorization', jwtToken);
        localStorage.setItem('userId', jwtUserId);
        localStorage.setItem('userName', jwtUserName);
        localStorage.setItem('authRole', jwtAuthRole);
        localStorage.setItem('isLogin', 'true');

        setInputs({ userId: '', userPassword: '' });
      })
      .then((response) => {
        //navigator('/'); 를 사용하려면 위에 const navigator = useNavigate(); 선언필요
        //페이지 리다이렉트
        console.log(localStorage.userId);
        alert('로그인에 성공했습니다.');
        navigator('/');
        //window.location.replace("/");
      })
      .catch((err) => {
        console.error(err.message);
        alert('아이디 또는 비밀번호를 확인해주세요.');
        //navigator("/login");
        window.location.href = '/login';
      });
  };

  return (
    <>
      {/* som */}

      <div className='container text-center mt-5'>
        <div className='mx-5'>
          <h1>🦄 로그인 🦄</h1>
          <form onSubmit={onSubmit}>
            <div className='form-group mt-1'>
              <input
                type='text'
                name='userId'
                className='form-control'
                id='userId'
                value={userId}
                placeholder='아이디'
                maxLength='20'
                onChange={handleValueChange}
              />
            </div>
            <div className='form-group mt-1'>
              <input
                type='password'
                className='form-control'
                name='userPassword'
                id='userPassword'
                value={userPassword}
                placeholder='비밀번호'
                maxLength='20'
                onChange={handleValueChange}
              />
            </div>
            <div className='mt-1'>
              <button type='submit' className='btn btn-primary'>
                로그인
              </button>
              <Link className='btn btn-primary' to='/signup'>
                회원 가입
              </Link>
            </div>
          </form>
        </div>
      </div>
      {/* som */}
      <SignArea>
        <div className='join_inner'>
          <h2>로그인</h2>
          <p>로그인 후 청년24의 다양한 서비스를 이용하세요.</p>
          <form>
            <div
              className={isIdFocused ? 'icon_input id_active' : 'icon_input'}
            >
              <FontAwesomeIcon
                icon={solidUser}
                className={isIdFocused ? 'id_active' : ''}
              ></FontAwesomeIcon>
              <input
                type='text'
                placeholder='아이디'
                onFocus={handleIdFocus}
                onBlur={handleIdBlur}
              />
            </div>
            <div
              className={isPwFocused ? 'icon_input pw_active' : 'icon_input'}
            >
              <FontAwesomeIcon
                icon={solidLock}
                className={isPwFocused ? 'pw_active' : ''}
              ></FontAwesomeIcon>
              <input
                type='password'
                placeholder='비밀번호'
                onFocus={handlePwFocus}
                onBlur={handlePwBlur}
              />
            </div>

            <label htmlFor='idSet' className='sign_checkbox'>
              <input type='checkbox' id='idSet' />
              <span className='cbx'>
                <svg width='15px' height='15px' viewBox='0 0 15 15'>
                  <polyline points='2 5 5 9 10 3'></polyline>
                </svg>
              </span>
              <span>아이디 기억하기</span>
            </label>

            <button className='submit_btn' type='submit' disabled>
              로그인
            </button>
          </form>

          <p>
            <NavLink to='/login/fineId'>아이디 찾기</NavLink>
            <span>·</span>
            <NavLink to='/login/resetPw'>비밀번호 재설정</NavLink>
            <span>·</span>
            <NavLink to='/signup'>회원가입</NavLink>
          </p>
        </div>
      </SignArea>
    </>
  );
};

export default Login;
