import { SignArea, SignupForm } from 'style/StyleJoin';

const FindId = () => {
  return (
    <>
      <SignArea>
        <div className='join_inner'>
          <h2>아이디 찾기</h2>
          <p>회원정보를 입력해주세요.</p>
          <SignupForm>
            <ul className='findid'>
              <li>
                <h4>성명</h4>
                <input type='text' placeholder='성명을 입력하세요.' />
              </li>
              <li>
                <h4>전화번호</h4>
                <input type='text' placeholder='000' />
                <input type='text' placeholder='0000' />
                <input type='text' placeholder='0000' />
                <p className='ok'>※ 숫자만 입력 가능합니다.</p>
              </li>
            </ul>
            <button className='submit_btn' type='submit' disabled>
              조회하기
            </button>
          </SignupForm>
        </div>
      </SignArea>
    </>
  );
};

export default FindId;
