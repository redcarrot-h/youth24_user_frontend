import { SignArea, SignupForm } from 'style/StyleJoin';

const ResetPwStep = () => {
  return (
    <>
      <SignArea>
        <div className='join_inner'>
          <h2>비밀번호 재설정</h2>
          <p>
            김누구(@@@@@@)님 계정이 확인되었습니다.
            <br />
            비밀번호를 재설정합니다.
          </p>
          <SignupForm>
            <ul className='resetpw'>
              <li>
                <h4>비밀번호</h4>
                <input type='password' placeholder='비밀번호를 입력하세요.' />
                <p>※ 영문 대문자, 소문자, 특수문자, 숫자 포함 8~16자리</p>
              </li>
              <li>
                <h4>비밀번호 재확인</h4>
                <input
                  type='password'
                  placeholder='비밀번호를 한번 더 입력하세요.'
                />
                <p>※ 비밀번호가 일치하지 않습니다.</p>
              </li>
            </ul>
            <button className='submit_btn' type='submit' disabled>
              확인
            </button>
          </SignupForm>
        </div>
      </SignArea>
    </>
  );
};

export default ResetPwStep;
