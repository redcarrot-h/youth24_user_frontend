import { SignArea, SignupForm } from 'style/StyleJoin';
import AddressPopup from 'components/util/AddressPopup';
// import AlertTwoBtn from 'components/util/AlertTwoBtn';
//import Alert from 'components/Alert';

// som
import { baseUrl } from 'apiurl';
import axios from 'axios';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Signup = () => {
  const [addrPopup, setAddrPopup] = useState(false);
  const [addrValue, setAddrValue] = useState({
    zonecode: '',
    address: '',
    sido: '',
  });

  const addrPopupHandle = () => {
    setAddrPopup(!addrPopup);
  };

  // const test = () => {
  //   alert('성공!!');
  // };

  // som
  const navigator = useNavigate();
  //초기화
  const [user, setUser] = useState({
    userId: '',
    userPassword: '',
    userName: '',
    userBirthdate: '',
    userGender: '',
    userAddress: '',
    userDistrict: '',
    userPhone: '',
    userEducation: '',
    userEmpstatus: '',
  });

  const [userId, setUserId] = useState('');
  const [usableId, setUsableId] = useState(false);
  const [userPassword, setUserPassword] = useState('');
  const [userIdValid, setUserIdValid] = useState(false);
  const [userPasswordValid, setUserPasswordValid] = useState(false);
  //const [userInfoValid, setUserInfoValid] = useState(false);
  //const [notAllow, setNotAllow] = useState(true);
  const [notIdCheck, setNotIdCheck] = useState(true);

  const config = { headers: { 'Content-Type': 'application/json' } };

  const idCheck = async (e) => {
    e.preventDefault();
    console.log('아이디 중복체크 시도');
    await axios
      .post(`${baseUrl}/user/signup/idCheck`, { userId: userId }, config)
      .then((response) => {
        if (response.data === 'retry') {
          alert('아이디를 입력해주세요.');
        } else if (response.data === 'no') {
          alert('이미 사용 중인 아이디입니다.');
          console.log('사용 불가');
          setUsableId(false);
        } else if (response.data === 'ok') {
          alert('사용 가능한 아이디입니다.');
          setUsableId(true);
        }
      })
      .catch((err) => {
        console.log('실패........');
        console.error(err.message);
      });
  };

  const onSubmit = async (e) => {
    console.log('시도');
    e.preventDefault();
    await axios
      .post(
        `${baseUrl}/signup`,
        //객체로 담음
        {
          userId: userId,
          userPassword: userPassword,
          userName: user.userName,
          userBirthdate: user.userBirthdate,
          userGender: user.userGender,
          userAddress: user.userAddress,
          userDistrict: user.userDistrict,
          userPhone: user.userPhone,
          userEducation: user.userEducation,
          userEmpstatus: user.userEmpstatus,
        },
        config
      )
      .then((response) => {
        setUser({
          userId: '',
          userPassword: '',
          userName: '',
          userBirthdate: '',
          userGender: '',
          userAddress: '',
          userDistrict: '',
          userPhone: '',
          userEducaiton: '',
          userEmpstatus: '',
        });
        console.log('성공');
        navigator('/');
        alert('회원가입이 완료되었습니다.');
      })
      .catch((err) => {
        console.log('실패');
        console.error(err.message);
      });
  };

  const handleIdChange = (e) => {
    //setUser({ ...user.userId, [e.target.name]: e.target.value });
    setUserId(e.target.value);
    const regexId = /^[a-z0-9]{3,11}$/;
    if (regexId.test(userId)) {
      setUserIdValid(true);
      setNotIdCheck(false);
    } else {
      setUserIdValid(false);
      setNotIdCheck(true);
    }
  };

  const handlePwChange = (e) => {
    setUserPassword(e.target.value);
    const regexPw = /^[a-z0-9]{4,12}$/;
    ///^(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,20}$/;
    if (regexPw.test(userPassword)) {
      setUserPasswordValid(true);
    } else {
      setUserPasswordValid(false);
    }
  };

  const handleValueChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  useEffect(() => {
    if (userIdValid && userPasswordValid && usableId) {
      //setNotAllow(false);
      return;
    }
    //setNotAllow(true);
  }, [userIdValid, userPasswordValid, usableId]);

  useEffect(() => {
    if (userIdValid) {
      setNotIdCheck(false);
      return;
    }
    setNotIdCheck(true);
  }, [userIdValid]);

  return (
    <>
      {/* som */}

      <div className='container'>
        <form onSubmit={onSubmit}>
          <div className='container'>
            <h1>회원가입</h1>
            <div className='form-group mb-1'>
              아이디
              <input
                type='text'
                className='form-control'
                name='userId'
                placeholder='아이디'
                value={userId}
                onChange={handleIdChange}
                required
              />
            </div>
            <div className='IdErrMessage'>
              {!userIdValid && userId.length > 0 && (
                <div>아이디를 확인해주세요. (영문소문자/숫자, 4~12자) </div>
              )}
            </div>
            <div>
              <button disabled={notIdCheck} onClick={idCheck}>
                중복확인
              </button>
            </div>

            <div className='form-group mb-1'>
              비밀번호
              <input
                type='password'
                className='form-control'
                name='userPassword'
                value={userPassword}
                placeholder='영문, 숫자, 특수문자 포함 8자~12자'
                onChange={handlePwChange}
                required
              />
            </div>
            <div className='PwErrMessage'>
              {!userPasswordValid && userPassword.length > 0 && (
                <div>비밀번호를 확인해주세요.</div>
              )}
            </div>
            <div className='form-group mb-1'>
              <input
                type='text'
                className='form-control'
                name='userName'
                placeholder='이름'
                onChange={handleValueChange}
                required
              />
            </div>

            <div className='form-group mb-1'>
              <input
                type='text'
                className='form-control'
                name='userBirthdate'
                placeholder='생년월일'
                onChange={handleValueChange}
                required
              />
            </div>

            <div className='form-group mb-1'>
              <input
                type='text'
                className='form-control'
                name='userGender'
                placeholder='성별'
                onChange={handleValueChange}
                required
              />
            </div>

            <div className='form-group mb-1'>
              <input
                type='text'
                className='form-control'
                name='userAddress'
                placeholder='주소'
                onChange={handleValueChange}
                required
              />
            </div>

            <div className='form-group mb-1'>
              <input
                type='text'
                className='form-control'
                name='userDistrict'
                placeholder='지역구'
                onChange={handleValueChange}
                required
              />
            </div>

            <div className='form-group mb-1'>
              <input
                type='text'
                className='form-control'
                name='userPhone'
                placeholder='전화번호'
                onChange={handleValueChange}
                required
              />
            </div>

            <div className='form-group mb-1'>
              <input
                type='text'
                className='form-control'
                name='userEducation'
                placeholder='학력'
                onChange={handleValueChange}
                required
              />
            </div>

            <div className='form-group mb-1'>
              <input
                type='text'
                className='form-control'
                name='userEmpstatus'
                placeholder='재직 / 무직'
                onChange={handleValueChange}
                required
              />
            </div>

            <button
              // disabled={!usableId}
              type='submit'
              className='btn btn-primary'
              style={{ width: '30%' }}
            >
              회원 가입
            </button>
          </div>
        </form>
      </div>
      {/* som */}

      {/* <AlertTwoBtn
        text={<p>아이디가 없습니다.</p>}
        btnOneText={'회원가입'}
        btnTwoText={'다시 조회하기'}
        btnOneLink={'/signup'}
        btnTwoLink={'/login/fineId'}
      /> */}

      {/* <button onClick={addrPopupHandle}>불러오기</button> */}
      {/* {addrPopup ? (
        <>
          <Alert
            offAlert={setAddrPopup}
            func={test}
            text={'테스트'}
            btntext={'버튼'}
          />
        </>
      ) : (
        ''
      )} */}

      <SignArea>
        <div className='join_inner'>
          <h2>회원가입</h2>
          <p>청년24 회원가입을 환영합니다.</p>
          <SignupForm>
            <ul className='signup'>
              <li>
                <h4>아이디</h4>
                <input type='text' placeholder='아이디를 입력하세요.' />
                <button type='button'>중복확인</button>
                <p>
                  ※ 아이디 중복확인을 해주세요. ※ 사용 가능한 아이디입니다. ※
                  사용중인 아이이디 입니다. 다른 아이디를 사용해주세요.
                </p>
              </li>
              <li>
                <h4>비밀번호</h4>
                <input type='password' placeholder='비밀번호를 입력하세요.' />
                <p>※ 영문 대문자, 소문자, 특수문자, 숫자 포함 8~16자리</p>
              </li>
              <li>
                <h4>비밀번호 재확인</h4>
                <input
                  type='password'
                  placeholder='비밀번호를 한번 더 입력하세요.'
                />
                <p>※ 비밀번호가 일치하지 않습니다.</p>
              </li>
              <li>
                <h4>성명</h4>
                <input type='text' placeholder='성명을 입력하세요.' />
                <p>※ 한글만 입력 가능합니다.</p>
              </li>
              <li>
                <h4>전화번호</h4>
                <input type='text' placeholder='000' />
                <input type='text' placeholder='0000' />
                <input type='text' placeholder='0000' />
                <p className='ok'>※ 숫자만 입력 가능합니다.</p>
              </li>
              <li>
                <h4>주소</h4>
                <input
                  type='text'
                  value={addrValue.zonecode}
                  placeholder='우편번호'
                  readOnly
                />
                <button type='button' onClick={addrPopupHandle}>
                  주소조회
                </button>
                <input
                  type='text'
                  value={addrValue.address}
                  placeholder='주소'
                  readOnly
                />
                <input type='text' placeholder='상세주소를 입력하세요.' />
                <input type='text' value={addrValue.sido} />
              </li>
              <li>
                <h4>생년월일</h4>
                <input type='text' placeholder='0000' />
                <input type='text' placeholder='00' />
                <input type='text' placeholder='00' />
                <p className='no'>※ 유효한 숫자만 입력 가능합니다.</p>
              </li>
              <li>
                <h4>성별</h4>
                <select>
                  <option value='' selected>
                    성별을 선택해주세요.
                  </option>
                  <option value='남성'>남성</option>
                  <option value='여성'>여성</option>
                </select>
              </li>
              <li>
                <h4>학력</h4>
                <select>
                  <option value='' selected>
                    학력을 선택해주세요.
                  </option>
                  <option value='고등학교 졸업 미만'>고등학교 졸업 미만</option>
                  <option value='고등학교 졸업'>고등학교 졸업</option>
                  <option value='대학교 재학중'>대학교 재학중</option>
                  <option value='대학교 졸업 예정'>대학교 졸업 예정</option>
                  <option value='대학교 졸업'>대학교 졸업</option>
                  <option value='석·박사'>석·박사</option>
                </select>
              </li>
              <li>
                <h4>구직상태</h4>
                <select>
                  <option value='' selected>
                    구직상태을 선택해주세요.
                  </option>
                  <option value='구직중'>구직중</option>
                  <optio value='근로중'>근로중</optio>
                </select>
              </li>
            </ul>
            <button className='submit_btn' type='submit' disabled>
              회원가입
            </button>
          </SignupForm>
        </div>
      </SignArea>

      {/* 주소찾기 popup */}
      {addrPopup ? (
        <AddressPopup setAddrValue={setAddrValue} Close={setAddrPopup} />
      ) : (
        ''
      )}
    </>
  );
};

export default Signup;
